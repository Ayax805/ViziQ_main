/**
 * VIZIQ — Основной сервер
 */

const express      = require('express');
const cookieParser = require('cookie-parser');
const cors         = require('cors');
const path         = require('path');
const os           = require('os');

const { initDb }         = require('./db');
const authRouter         = require('./routes/auth');
const cardsRouter        = require('./routes/cards');
const uploadRouter       = require('./routes/upload');
const publicRouter       = require('./routes/public');
const { authMiddleware } = require('./middleware/auth');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Определяем свой IP в локальной сети ──────────────────────────────────────
function getLocalIP() {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
        for (const iface of ifaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) return iface.address;
        }
    }
    return 'localhost';
}
const LOCAL_IP = getLocalIP();
// Делаем IP доступным всему приложению
app.set('localIP', LOCAL_IP);
app.set('port', PORT);

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
// Отдаём загруженные картинки
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── API маршруты ──────────────────────────────────────────────────────────────
app.use('/api/auth',   authRouter);
app.use('/api/cards',  authMiddleware, cardsRouter);
app.use('/api/upload', authMiddleware, uploadRouter);
app.use('/api/public', publicRouter);   // публичный просмотр визиток — без авторизации

// Отдать IP клиенту (нужен для генерации QR-ссылки)
app.get('/api/server-info', (req, res) => {
    res.json({ ip: LOCAL_IP, port: PORT });
});

// ── Обработка ошибок ──────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
    console.error('[ERROR]', err.message);
    res.status(err.status || 500).json({
        ok:      false,
        code:    err.code    || 'INTERNAL_ERROR',
        message: err.message || 'Внутренняя ошибка сервера'
    });
});

// ── Старт ─────────────────────────────────────────────────────────────────────
initDb();
app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅  VIZIQ запущен:`);
    console.log(`    Локально:  http://localhost:${PORT}`);
    console.log(`    В сети:    http://${LOCAL_IP}:${PORT}`);
});
