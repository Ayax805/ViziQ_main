/**
 * routes/cards.js — CRUD визиток
 */

const express = require('express');
const router  = express.Router();
const { query, get, run } = require('../db');

// GET /api/cards
router.get('/', (req, res) => {
    const rows = query(
        'SELECT id, type, title, data, created_at, updated_at FROM cards WHERE user_id = ? ORDER BY created_at DESC',
        [req.user.id]
    );
    res.json({ ok: true, cards: rows.map(c => ({ ...c, data: safeJson(c.data) })) });
});

// GET /api/cards/:id
router.get('/:id', (req, res) => {
    const card = get(
        'SELECT id, type, title, data, created_at, updated_at FROM cards WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.id]
    );
    if (!card) return res.status(404).json({ ok: false, code: 'CARD_NOT_FOUND', message: 'Визитка не найдена' });
    res.json({ ok: true, card: { ...card, data: safeJson(card.data) } });
});

// POST /api/cards
router.post('/', (req, res) => {
    const { type, title, data } = req.body;
    if (!type || !['personal', 'company'].includes(type)) {
        return res.status(400).json({ ok: false, code: 'VALIDATION_ERROR', message: 'type должен быть "personal" или "company"' });
    }
    run(
        'INSERT INTO cards (user_id, type, title, data) VALUES (?, ?, ?, ?)',
        [req.user.id, type, (title || 'Моя визитка').trim(), JSON.stringify(data || {})]
    );
    const card = get(
        'SELECT id, type, title, data, created_at FROM cards WHERE user_id = ? ORDER BY id DESC LIMIT 1',
        [req.user.id]
    );
    res.status(201).json({ ok: true, code: 'CARD_CREATED', card: { ...card, data: safeJson(card.data) } });
});

// PUT /api/cards/:id  — обновляет title И data за один запрос
router.put('/:id', (req, res) => {
    const existing = get(
        'SELECT id, data FROM cards WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.id]
    );
    if (!existing) return res.status(404).json({ ok: false, code: 'CARD_NOT_FOUND', message: 'Визитка не найдена' });

    const { title, data } = req.body;

    // Мерж данных на уровне сервера — гарантия что ничего не потеряется
    const oldData  = safeJson(existing.data);
    const newData  = (data && typeof data === 'object') ? Object.assign({}, oldData, data) : oldData;
    const newTitle = (title && title.trim()) ? title.trim() : undefined;

    run(
        `UPDATE cards SET
            title      = COALESCE(?, title),
            data       = ?,
            updated_at = datetime('now')
         WHERE id = ?`,
        [newTitle || null, JSON.stringify(newData), req.params.id]
    );

    const card = get(
        'SELECT id, type, title, data, created_at, updated_at FROM cards WHERE id = ?',
        [req.params.id]
    );
    res.json({ ok: true, code: 'CARD_UPDATED', card: { ...card, data: safeJson(card.data) } });
});

// DELETE /api/cards/:id
router.delete('/:id', (req, res) => {
    const existing = get('SELECT id FROM cards WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!existing) return res.status(404).json({ ok: false, code: 'CARD_NOT_FOUND', message: 'Визитка не найдена' });
    run('DELETE FROM cards WHERE id = ?', [req.params.id]);
    res.json({ ok: true, code: 'CARD_DELETED', message: 'Визитка удалена' });
});

function safeJson(str) {
    try { return JSON.parse(str); } catch { return {}; }
}

module.exports = router;
