/**
 * routes/upload.js
 * POST /api/upload/avatar      — фото профиля пользователя
 * POST /api/upload/card-photo  — фото для визитки
 *
 * Файлы сохраняются в папку uploads/ и отдаются как /uploads/filename
 */

const express = require('express');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { run, get } = require('../db');

const router = express.Router();

// Папка для хранения
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// Настройка multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOAD_DIR),
    filename: (req, file, cb) => {
        const ext  = path.extname(file.originalname).toLowerCase() || '.jpg';
        const name = `${Date.now()}_${req.user.id}${ext}`;
        cb(null, name);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 },  // 5 МБ
    fileFilter: (req, file, cb) => {
        const allowed = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
        const ext = path.extname(file.originalname).toLowerCase();
        if (allowed.includes(ext)) cb(null, true);
        else cb(new Error('Разрешены только изображения (jpg, png, webp, gif)'));
    }
});

// ── POST /api/upload/avatar ───────────────────────────────────────────────────
router.post('/avatar', upload.single('photo'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ ok: false, code: 'NO_FILE', message: 'Файл не передан' });
    }

    const url = `/uploads/${req.file.filename}`;

    // Удалить старый аватар пользователя если есть
    const user = get('SELECT avatar FROM users WHERE id = ?', [req.user.id]);
    if (user?.avatar) deleteFile(user.avatar);

    run('UPDATE users SET avatar = ? WHERE id = ?', [url, req.user.id]);

    res.json({ ok: true, url });
});

// ── POST /api/upload/card-photo ───────────────────────────────────────────────
router.post('/card-photo', upload.single('photo'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ ok: false, code: 'NO_FILE', message: 'Файл не передан' });
    }
    // Просто возвращаем URL — клиент сам сохранит его в data визитки
    const url = `/uploads/${req.file.filename}`;
    res.json({ ok: true, url });
});

function deleteFile(url) {
    try {
        const filePath = path.join(__dirname, '..', url);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    } catch {}
}

// Обработка ошибок multer
router.use((err, req, res, next) => {
    res.status(400).json({ ok: false, code: 'UPLOAD_ERROR', message: err.message });
});

module.exports = router;
