/**
 * js/settings.js — страницы настройки визиток
 *
 * Исправлено:
 *  1. Сбор данных идёт по уникальным именам полей, а не по id (обходит дубли id в HTML)
 *  2. Фото визитки корректно восстанавливается при загрузке
 *  3. При сохранении данные МЕРЖАТСЯ с существующими, а не перезаписываются с нуля
 */

window.addEventListener('viziq:authReady', async ({ detail }) => {
    const { cards, isGuest } = window.VIZIQ;

    if (isGuest) {
        alert('Для работы с визитками необходимо войти.');
        window.location = 'registration_window.html';
        return;
    }

    const isCompany = window.location.pathname.includes('Campaign');
    const cardType  = isCompany ? 'company' : 'personal';
    const urlParams = new URLSearchParams(window.location.search);
    const cardId    = urlParams.get('id') || null;

    let currentCard = null;

    // ── Карта полей ───────────────────────────────────────────────────────────
    // Проблема: в HTML один и тот же id встречается несколько раз (PhoneNumber, work).
    // Решение: собираем ВСЕ input-ы по placeholder/label, используем первое вхождение
    // для каждого смыслового ключа, а для дублей — берём тот, у которого есть значение.

    // Уникальные ключи данных для персональной визитки
    const PERSONAL_FIELDS = ['fullName', 'work', 'placework', 'PhoneNumber', 'name', 'socialMedia', 'sved'];
    // Уникальные ключи данных для корпоративной визитки
    const COMPANY_FIELDS  = ['campaignName', 'office', 'hot_line', 'naprav', 'sved'];

    const FIELD_KEYS = isCompany ? COMPANY_FIELDS : PERSONAL_FIELDS;

    /**
     * Собрать данные формы.
     * Для каждого ключа перебираем ВСЕ элементы с этим id и берём
     * первый непустой. Так обходим проблему дублирующихся id в HTML.
     */
    function collectData() {
        const data = {};

        FIELD_KEYS.forEach(key => {
            // querySelectorAll находит ВСЕ элементы с данным id (включая дубли)
            const elements = document.querySelectorAll(`#${key}`);
            let value = '';
            elements.forEach(el => {
                if (!value && el.value.trim()) value = el.value.trim();
            });
            if (value) data[key] = value;
        });

        // Фото визитки
        const photoUrl = _getCardPhotoUrl();
        if (photoUrl) data.cardPhoto = photoUrl;

        return data;
    }

    /**
     * Заполнить форму из сохранённых данных.
     * Для дублирующихся id заполняем ВСЕ одинаковые поля одним значением.
     */
    function fillForm(data) {
        if (!data || typeof data !== 'object') return;

        FIELD_KEYS.forEach(key => {
            if (data[key] === undefined) return;
            const elements = document.querySelectorAll(`#${key}`);
            elements.forEach(el => { el.value = data[key]; });
        });

        // Восстановить фото визитки
        if (data.cardPhoto) {
            setCardPhoto(data.cardPhoto);
        }
    }

    // ── Загрузить существующую визитку ────────────────────────────────────────
    if (cardId) {
        const result = await cards.get(cardId);
        if (result.ok) {
            currentCard = result.card;
            fillForm(currentCard.data);
        } else {
            showError('Визитка не найдена. Будет создана новая.');
        }
    }

    // ── Фото визитки ──────────────────────────────────────────────────────────
    const vizitAvatar = document.getElementById('vizitAvatar');

    if (vizitAvatar) {
        vizitAvatar.style.cursor = 'pointer';
        vizitAvatar.title = 'Нажмите чтобы загрузить фото';

        // Иконка-подсказка
        const wrapper = vizitAvatar.parentElement;
        wrapper.style.position = 'relative';
        const hint = document.createElement('div');
        hint.innerHTML = '📷';
        hint.style.cssText = [
            'position:absolute', 'bottom:5px', 'right:5px',
            'background:rgba(0,0,0,.55)', 'color:white',
            'border-radius:50%', 'width:26px', 'height:26px',
            'display:flex', 'align-items:center', 'justify-content:center',
            'font-size:14px', 'pointer-events:none', 'z-index:2'
        ].join(';');
        wrapper.appendChild(hint);

        vizitAvatar.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type   = 'file';
            input.accept = 'image/*';
            input.onchange = async () => {
                const file = input.files[0];
                if (!file) return;
                const fd = new FormData();
                fd.append('photo', file);
                try {
                    const res  = await fetch('/api/upload/card-photo', {
                        method: 'POST', credentials: 'include', body: fd
                    });
                    const json = await res.json();
                    if (json.ok) {
                        setCardPhoto(json.url);
                        showSuccess('Фото загружено. Не забудьте сохранить.');
                    } else {
                        showError(json.message || 'Ошибка загрузки');
                    }
                } catch { showError('Ошибка загрузки фото'); }
            };
            input.click();
        });
    }

    /** Установить фото визитки: обновить <img> и запомнить URL */
    function setCardPhoto(url) {
        if (!url) return;
        if (vizitAvatar) {
            vizitAvatar.src = url;
        }
        // Скрытый input — единственный надёжный способ хранить URL между collectData()
        let hidden = document.getElementById('_cardPhotoUrl');
        if (!hidden) {
            hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.id   = '_cardPhotoUrl';
            document.body.appendChild(hidden);
        }
        hidden.value = url;
    }

    function _getCardPhotoUrl() {
        const el = document.getElementById('_cardPhotoUrl');
        return el ? el.value : '';
    }

    // ── Сохранить ─────────────────────────────────────────────────────────────
    async function handleSave() {
        const newData = collectData();

        // МЕРЖ: берём старые данные и поверх кладём новые.
        // Это защищает поля, которые есть в одной панели, но не в другой.
        const mergedData = Object.assign({}, currentCard?.data || {}, newData);

        const title = isCompany
            ? (mergedData.campaignName || 'Корпоративная визитка')
            : (mergedData.fullName || mergedData.name || 'Личная визитка');

        let result;
        if (currentCard) {
            result = await cards.update(currentCard.id, { title, data: mergedData });
        } else {
            result = await cards.create({ type: cardType, title, data: mergedData });
        }

        if (result.ok) {
            currentCard = result.card;
            history.replaceState(null, '', `?id=${currentCard.id}`);
            showSuccess('Сохранено!');

            // Обновить кнопку просмотра если есть
            const viewBtn = document.getElementById('viewCard');
            if (viewBtn) {
                viewBtn.style.display = '';
                viewBtn.href = `card-view.html?id=${currentCard.id}`;
            }
        } else {
            showError(result.message || 'Ошибка сохранения');
        }
    }

    function handleReset() {
        if (currentCard) {
            fillForm(currentCard.data);
            showSuccess('Изменения сброшены');
        } else {
            FIELD_KEYS.forEach(key => {
                document.querySelectorAll(`#${key}`).forEach(el => { el.value = ''; });
            });
        }
    }

    // ── Кнопки ────────────────────────────────────────────────────────────────
    ['save', 'save2'].forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.addEventListener('click', async () => {
            btn.disabled    = true;
            btn.textContent = 'Сохранение...';
            await handleSave();
            btn.disabled   = false;
            btn.innerHTML  = '<b>Сохранить изменения</b>';
        });
    });

    ['reset', 'reset2'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.addEventListener('click', handleReset);
    });

    // ── Кнопка просмотра ──────────────────────────────────────────────────────
    const viewBtn = document.getElementById('viewCard');
    if (viewBtn) {
        if (cardId) {
            viewBtn.style.display = '';
            viewBtn.href = `card-view.html?id=${cardId}`;
        } else {
            viewBtn.style.display = 'none';
        }
    }
});
