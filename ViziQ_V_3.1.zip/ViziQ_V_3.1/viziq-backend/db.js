/**
 * db.js — инициализация SQLite через sql.js
 *
 * sql.js — это SQLite, скомпилированный в WebAssembly, без нативных модулей.
 * База данных хранится в файле viziq.db (бинарный формат SQLite).
 * При каждом изменении база сохраняется на диск.
 */

const initSqlJs = require('sql.js');
const fs        = require('fs');
const path      = require('path');

const DB_PATH = path.join(__dirname, 'viziq.db');

let db = null;   // глобальный объект базы данных

/** Сохранить базу на диск */
function persist() {
    const data = db.export();   // Uint8Array
    fs.writeFileSync(DB_PATH, Buffer.from(data));
}

/** Инициализировать БД (создать таблицы если не существуют) */
async function initDb() {
    const SQL = await initSqlJs();

    if (fs.existsSync(DB_PATH)) {
        const fileBuffer = fs.readFileSync(DB_PATH);
        db = new SQL.Database(fileBuffer);
        console.log('📂  БД загружена из', DB_PATH);
    } else {
        db = new SQL.Database();
        console.log('🆕  Создана новая БД');
    }

    // Таблица пользователей
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            email       TEXT    NOT NULL UNIQUE,
            password    TEXT    NOT NULL,
            username    TEXT    NOT NULL,
            avatar      TEXT    DEFAULT NULL,
            role        TEXT    DEFAULT 'user',
            created_at  TEXT    DEFAULT (datetime('now'))
        )
    `);
    // Миграция: добавить avatar если БД уже существовала без него
    try { db.run(`ALTER TABLE users ADD COLUMN avatar TEXT DEFAULT NULL`); } catch {}
    // Миграция: добавить role если БД уже существовала без него
    try { db.run(`ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'`); } catch {}

    // Таблица визиток
    db.run(`
        CREATE TABLE IF NOT EXISTS cards (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            type        TEXT    NOT NULL CHECK(type IN ('personal','company')),
            title       TEXT    NOT NULL DEFAULT 'Моя визитка',
            data        TEXT    NOT NULL DEFAULT '{}',
            created_at  TEXT    DEFAULT (datetime('now')),
            updated_at  TEXT    DEFAULT (datetime('now')),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    `);

    // Таблица сессий (токены refresh — запоминание на сутки)
    db.run(`
        CREATE TABLE IF NOT EXISTS sessions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            token       TEXT    NOT NULL UNIQUE,
            expires_at  TEXT    NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    `);

    persist();
    console.log('✅  Таблицы готовы');
}

/** Выполнить SELECT, вернуть массив объектов */
function query(sql, params = []) {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const rows = [];
    while (stmt.step()) {
        rows.push(stmt.getAsObject());
    }
    stmt.free();
    return rows;
}

/** Выполнить INSERT/UPDATE/DELETE и сохранить на диск */
function run(sql, params = []) {
    db.run(sql, params);
    persist();
}

/** Вернуть один объект или null */
function get(sql, params = []) {
    const rows = query(sql, params);
    return rows.length ? rows[0] : null;
}

module.exports = { initDb, query, run, get };
