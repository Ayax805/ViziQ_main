/**
 * VIZIQ — Основной сервер
 */

const express      = require('express');
const cookieParser = require('cookie-parser');
const cors         = require('cors');
const path         = require('path');
const os           = require('os');

const { initDb }         = require('./db');
const authRouter         = require('./routes/auth');
const cardsRouter        = require('./routes/cards');
const uploadRouter       = require('./routes/upload');
const publicRouter       = require('./routes/public');
const { authMiddleware }  = require('./middleware/auth');
const { adminMiddleware } = require('./middleware/adminAuth');
const adminRouter         = require('./routes/admin');


const app  = express();
const PORT = process.env.PORT || 3000;

// ── Определяем свой IP в локальной сети ──────────────────────────────────────
function getLocalIP() {
    const ifaces = os.networkInterfaces();
    for (const name of Object.keys(ifaces)) {
        for (const iface of ifaces[name]) {
            if (iface.family === 'IPv4' && !iface.internal) return iface.address;
        }
    }
    return 'localhost';
}
const LOCAL_IP = getLocalIP();
// Делаем IP доступным всему приложению
app.set('localIP', LOCAL_IP);
app.set('port', PORT);

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
// Отдаём загруженные картинки
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── API маршруты ──────────────────────────────────────────────────────────────
app.use('/api/auth',   authRouter);
app.use('/api/cards',  authMiddleware, cardsRouter);
app.use('/api/upload', authMiddleware, uploadRouter);
app.use('/api/public', publicRouter);   // публичный просмотр визиток — без авторизации

// Начальная настройка первого администратора (без проверки admin роли)
app.post('/api/setup/make-first-admin', authMiddleware, (req, res) => {
    const { get: dbGet, run: dbRun } = require('./db');
    const admins = dbGet("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
    if (admins && admins.count > 0) {
        return res.status(403).json({ ok: false, code: 'ADMIN_EXISTS', message: 'Администратор уже существует' });
    }
    dbRun("UPDATE users SET role = 'admin' WHERE id = ?", [req.user.id]);
    res.json({ ok: true, code: 'FIRST_ADMIN_SET', message: 'Вы назначены первым администратором!' });
});
app.use('/api/admin', authMiddleware, adminMiddleware, adminRouter);

// Главная страница сервиса
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'Main-Page.html'));
});


// Отдать IP клиенту (нужен для генерации QR-ссылки)
app.get('/api/server-info', (req, res) => {
    res.json({ ip: LOCAL_IP, port: PORT });
});

// ── Обработка ошибок ──────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
    console.error('[ERROR]', err.message);
    res.status(err.status || 500).json({
        ok:      false,
        code:    err.code    || 'INTERNAL_ERROR',
        message: err.message || 'Внутренняя ошибка сервера'
    });
});

// ── Старт ─────────────────────────────────────────────────────────────────────
initDb();
app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅  VIZIQ запущен:`);
    console.log(`    Локально:  http://localhost:${PORT}`);
    console.log(`    В сети:    http://${LOCAL_IP}:${PORT}`);
});
