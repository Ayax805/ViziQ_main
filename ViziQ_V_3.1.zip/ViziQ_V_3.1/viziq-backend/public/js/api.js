/**
 * js/api.js — клиентский хелпер запросов
 */

const API_BASE = '/api';

async function apiFetch(method, path, body = null) {
    const opts = {
        method,
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
        const res  = await fetch(API_BASE + path, opts);
        const data = await res.json();
        return data;
    } catch {
        return { ok: false, code: 'NETWORK_ERROR', message: 'Нет соединения с сервером.' };
    }
}

const auth = {
    register: (d) => apiFetch('POST', '/auth/register', d),
    login:    (d) => apiFetch('POST', '/auth/login', d),
    logout:   ()  => apiFetch('POST', '/auth/logout'),
    me:       ()  => apiFetch('GET',  '/auth/me'),
};

const cards = {
    list:   ()       => apiFetch('GET',    '/cards'),
    get:    (id)     => apiFetch('GET',    `/cards/${id}`),
    create: (d)      => apiFetch('POST',   '/cards', d),
    update: (id, d)  => apiFetch('PUT',    `/cards/${id}`, d),
    remove: (id)     => apiFetch('DELETE', `/cards/${id}`),
};

const session = {
    save(user)  { localStorage.setItem('viziq_user', JSON.stringify(user)); },
    load()      { try { return JSON.parse(localStorage.getItem('viziq_user')); } catch { return null; } },
    clear()     { localStorage.removeItem('viziq_user'); },
    isGuest()   { return !this.load(); }
};

window.VIZIQ = { auth, cards, session };
