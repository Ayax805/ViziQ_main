/**
 * js/authState.js
 * Проверяет сессию, обновляет шапку (имя, аватар, кнопки) на всех страницах.
 */

(async function () {
    const { auth, session } = window.VIZIQ;

    let currentUser = session.load();

    try {
        const result = await auth.me();
        if (result.ok) {
            currentUser = result.user;   // содержит avatar
            session.save(currentUser);
        } else {
            currentUser = null;
            session.clear();
        }
    } catch { /* сервер недоступен — используем кэш */ }

    window.VIZIQ.currentUser = currentUser;
    window.VIZIQ.isGuest     = !currentUser;

    updateHeader(currentUser);

    // ── Обновление шапки ─────────────────────────────────────────────────────
    function updateHeader(user) {
        const DEFAULT_AVATAR = 'avatar.png';

        // 1. Аватар #avatar — заменяем src
        const avatarImg = document.getElementById('avatar');
        if (avatarImg) {
            avatarImg.src = (user && user.avatar) ? user.avatar : DEFAULT_AVATAR;
            avatarImg.style.cursor = 'default';
        }

        // 2. Span рядом с #avatar — имя пользователя
        if (avatarImg) {
            let sib = avatarImg.nextElementSibling;
            while (sib) {
                if (sib.tagName === 'SPAN') {
                    sib.innerHTML = `<b>${escHtml(user ? shortName(user.username) : 'Гость')}</b>`;
                    break;
                }
                sib = sib.nextElementSibling;
            }
        }

        // 3. Маленький аватар в profile-Page (в шапке без id="avatar")
        document.querySelectorAll('img.rounded-circle[style*="45px"], img.rounded-circle[style*="width: 45px"]').forEach(img => {
            if (user && user.avatar) img.src = user.avatar;
        });

        // 4. Имена через data-username
        document.querySelectorAll('[data-username]').forEach(el => {
            el.textContent = user ? shortName(user.username) : 'Гость';
        });

        // 5. Кнопка Регистрация/Вход → Выйти
        const regBtn = document.getElementById('reg');
        if (regBtn) {
            if (user) {
                regBtn.textContent = 'Выйти';
                regBtn.style.backgroundColor = '#dc3545';
                regBtn.style.borderColor = '#dc3545';
                regBtn.onclick = async (e) => {
                    e.preventDefault();
                    await auth.logout();
                    session.clear();
                    window.location.href = 'Main-Page.html';
                };
            } else {
                regBtn.textContent = 'Регистрация / Вход';
                regBtn.style.backgroundColor = '#637dff';
                regBtn.style.borderColor = '#637dff';
                regBtn.onclick = (e) => {
                    e.preventDefault();
                    window.location.href = 'registration_window.html';
                };
            }
        }

        // 6. Гость/авторизован — show/hide по data-атрибутам
        document.querySelectorAll('[data-guest-only]').forEach(el => { el.style.display = user ? 'none' : ''; });
        document.querySelectorAll('[data-auth-only]').forEach(el => { el.style.display = user ? '' : 'none'; });
    }

    // "Иванов Иван Иванович" → "Иванов И.И."
    function shortName(username) {
        if (!username) return 'Пользователь';
        const parts = username.trim().split(/\s+/);
        if (parts.length === 1) return parts[0];
        return parts[0] + ' ' + parts.slice(1).map(p => p[0].toUpperCase() + '.').join('');
    }

    function escHtml(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }

    // ── Toast-уведомления ─────────────────────────────────────────────────────
    function showToast(message, type = 'danger') {
        document.querySelectorAll('.viziq-toast').forEach(t => t.remove());
        if (!document.getElementById('_vts')) {
            const s = document.createElement('style');
            s.id = '_vts';
            s.textContent = '@keyframes _vIn{from{transform:translateX(110%);opacity:0}to{transform:translateX(0);opacity:1}}';
            document.head.appendChild(s);
        }
        const t = document.createElement('div');
        t.className = `viziq-toast alert alert-${type} shadow`;
        t.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;min-width:280px;max-width:400px;animation:_vIn .3s ease';
        t.innerHTML = `<strong>${type==='danger'?'❌ Ошибка':'✅ Успешно'}</strong><br>${escHtml(message)}`;
        document.body.appendChild(t);
        setTimeout(() => t.remove(), 4000);
    }

    window.showError   = (m) => showToast(m, 'danger');
    window.showSuccess = (m) => showToast(m, 'success');

    window.dispatchEvent(new CustomEvent('viziq:authReady', { detail: { user: currentUser } }));
})();
