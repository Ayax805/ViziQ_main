/**
 * js/main.js — логика главной страницы (Main-Page.html)
 *
 * Подключить:
 *   <script src="js/api.js"></script>
 *   <script src="js/authState.js"></script>
 *   <script src="js/main.js"></script>
 */

(function () {
    // authState.js уже обрабатывает кнопку #reg и имя пользователя.
    // Здесь добавляем только навигацию по кнопкам.

    const createBtn = document.getElementById('create');
    if (createBtn) {
        createBtn.addEventListener('click', () => window.location = 'choice.html');
    }

    const btaBtn = document.getElementById('bta');
    if (btaBtn) {
        btaBtn.addEventListener('click', () => window.location = 'choice.html');
    }
})();
