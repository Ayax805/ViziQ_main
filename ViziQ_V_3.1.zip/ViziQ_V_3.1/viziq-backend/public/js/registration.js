/**
 * js/registration.js — логика страницы регистрации/входа
 *
 * Подключить в registration_window.html:
 *   <script src="js/api.js"></script>
 *   <script src="js/registration.js"></script>
 */

(function () {
    const { auth, session } = window.VIZIQ;

    // ── Переключение панелей Вход ↔ Регистрация ───────────────────────────────
    const card    = document.querySelector('.position-relative');
    const regBtn  = document.getElementById('regBtn');
    const entBtn  = document.getElementById('EntBtnFromReg');

    if (regBtn)  regBtn.addEventListener('click',  () => card?.classList.add('active'));
    if (entBtn)  entBtn.addEventListener('click',  () => card?.classList.remove('active'));

    // ── Форма ВХОДА ───────────────────────────────────────────────────────────
    // Кнопка "Войти" — первая в документе
    const loginBtn = document.querySelector('#Ent .btn:not(#regBtn)');
    if (loginBtn) {
        loginBtn.addEventListener('click', handleLogin);
    }

    async function handleLogin() {
        const emailInput = document.querySelector('#Ent input[type="email"]');
        const passInput  = document.querySelector('#Ent input[type="password"]');

        if (!emailInput || !passInput) return;

        const email    = emailInput.value.trim();
        const password = passInput.value;

        if (!email || !password) {
            showFieldError(emailInput, 'Заполните все поля');
            return;
        }

        setLoading(loginBtn, true, 'Вход...');

        const result = await auth.login({ email, password });

        setLoading(loginBtn, false, 'Войти');

        if (result.ok) {
            session.save(result.user);
            showBanner('success', `Добро пожаловать, ${result.user.username}!`);
            setTimeout(() => window.location = 'Main-Page.html', 1000);
        } else {
            showBanner('danger', formatError(result));
        }
    }

    // ── Форма РЕГИСТРАЦИИ ─────────────────────────────────────────────────────
    const registerBtn = document.querySelector('#Reg .btn:not(#EntBtnFromReg)');
    if (registerBtn) {
        registerBtn.addEventListener('click', handleRegister);
    }

    async function handleRegister() {
        const usernameInput = document.querySelector('#Reg input[type="text"]');
        const emailInput    = document.querySelector('#Reg input[type="email"]');
        const passInput     = document.querySelector('#Reg input[type="password"]');

        if (!usernameInput || !emailInput || !passInput) return;

        const username = usernameInput.value.trim();
        const email    = emailInput.value.trim();
        const password = passInput.value;

        if (!username || !email || !password) {
            showBanner('danger', 'Заполните все поля');
            return;
        }

        setLoading(registerBtn, true, 'Регистрация...');

        const result = await auth.register({ username, email, password });

        setLoading(registerBtn, false, 'Зарегистрироваться');

        if (result.ok) {
            session.save(result.user);
            showBanner('success', 'Аккаунт создан! Перенаправление...');
            setTimeout(() => window.location = 'Main-Page.html', 1000);
        } else {
            showBanner('danger', formatError(result));
        }
    }

    // ── Вспомогательные функции ───────────────────────────────────────────────

    /** Перевести код ошибки в понятное сообщение */
    function formatError(result) {
        const messages = {
            EMAIL_TAKEN:        'Этот email уже занят. Попробуйте войти.',
            WRONG_CREDENTIALS:  'Неверный email или пароль.',
            WEAK_PASSWORD:      'Пароль должен содержать минимум 6 символов.',
            INVALID_EMAIL:      'Введите корректный email-адрес.',
            VALIDATION_ERROR:   'Заполните все обязательные поля.',
            NETWORK_ERROR:      'Нет связи с сервером. Попробуйте позже.',
        };
        return messages[result.code] || result.message || 'Неизвестная ошибка';
    }

    /** Показать баннер с ошибкой/успехом внутри блока */
    function showBanner(type, text) {
        removeBanners();
        const div = document.createElement('div');
        div.className = `alert alert-${type} viziq-banner mt-3`;
        div.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:9999;min-width:280px;text-align:center;';
        div.textContent = text;
        document.body.appendChild(div);
        setTimeout(removeBanners, 3500);
    }

    function removeBanners() {
        document.querySelectorAll('.viziq-banner').forEach(b => b.remove());
    }

    function setLoading(btn, loading, label) {
        btn.disabled    = loading;
        btn.textContent = loading ? label : btn.dataset.label || label;
        if (!loading && !btn.dataset.label) btn.dataset.label = label;
    }

    function showFieldError(input, msg) {
        input.classList.add('is-invalid');
        let fb = input.nextElementSibling;
        if (!fb || !fb.classList.contains('invalid-feedback')) {
            fb = document.createElement('div');
            fb.className = 'invalid-feedback';
            input.parentNode.insertBefore(fb, input.nextSibling);
        }
        fb.textContent = msg;
        setTimeout(() => input.classList.remove('is-invalid'), 3000);
    }

    // Если уже залогинен — редирект
    const cached = session.load();
    if (cached) {
        window.location = 'Main-Page.html';
    }
})();
