/**
 * js/settings.js — страницы настройки визиток
 *
 * Запускается двумя путями:
 *  1. Обычная загрузка страницы — ждём viziq:authReady от authState.js
 *  2. Возврат через кнопку "Назад" (bfcache) — ловим pageshow и инициализируем заново
 */

let _initialized = false;

function initSettings() {
    // Защита от двойной инициализации
    if (_initialized) return;
    _initialized = true;

    // Ждём пока VIZIQ.isGuest будет определён (authState мог ещё не завершиться)
    const { cards, isGuest } = window.VIZIQ;

    if (isGuest) {
        alert('Для работы с визитками необходимо войти.');
        window.location = 'registration_window.html';
        return;
    }

    const isCompany = window.location.pathname.includes('Campaign');
    const cardType  = isCompany ? 'company' : 'personal';
    const urlParams = new URLSearchParams(window.location.search);
    const cardId    = urlParams.get('id') || null;

    let currentCard = null;

    const PERSONAL_FIELDS = ['fullName', 'work', 'placework', 'PhoneNumber', 'name', 'socialMedia', 'sved'];
    const COMPANY_FIELDS  = ['campaignName', 'office', 'hot_line', 'naprav', 'sved'];
    const FIELD_KEYS = isCompany ? COMPANY_FIELDS : PERSONAL_FIELDS;

    // ── Сбор данных формы ─────────────────────────────────────────────────────
    // querySelectorAll обходит дублирующиеся id в HTML (PhoneNumber, work встречаются дважды)
    function collectData() {
        const data = {};
        FIELD_KEYS.forEach(key => {
            let value = '';
            document.querySelectorAll(`#${key}`).forEach(el => {
                if (!value && el.value.trim()) value = el.value.trim();
            });
            if (value) data[key] = value;
        });
        const photoUrl = _getCardPhotoUrl();
        if (photoUrl) data.cardPhoto = photoUrl;
        return data;
    }

    // ── Заполнить форму ───────────────────────────────────────────────────────
    function fillForm(data) {
        if (!data || typeof data !== 'object') return;
        FIELD_KEYS.forEach(key => {
            if (data[key] === undefined) return;
            document.querySelectorAll(`#${key}`).forEach(el => { el.value = data[key]; });
        });
        if (data.cardPhoto) setCardPhoto(data.cardPhoto);
    }

    // ── Фото визитки ──────────────────────────────────────────────────────────
    const vizitAvatar = document.getElementById('vizitAvatar');

    function setCardPhoto(url) {
        if (!url) return;
        if (vizitAvatar) vizitAvatar.src = url;
        let hidden = document.getElementById('_cardPhotoUrl');
        if (!hidden) {
            hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.id   = '_cardPhotoUrl';
            document.body.appendChild(hidden);
        }
        hidden.value = url;
    }

    function _getCardPhotoUrl() {
        const el = document.getElementById('_cardPhotoUrl');
        return el ? el.value : '';
    }

    if (vizitAvatar) {
        vizitAvatar.style.cursor = 'pointer';
        vizitAvatar.title = 'Нажмите чтобы загрузить фото';

        // Иконка-подсказка — добавляем только один раз
        if (!vizitAvatar.parentElement.querySelector('._photo_hint')) {
            const wrapper = vizitAvatar.parentElement;
            wrapper.style.position = 'relative';
            const hint = document.createElement('div');
            hint.className = '_photo_hint';
            hint.textContent = '📷';
            hint.style.cssText = 'position:absolute;bottom:5px;right:5px;background:rgba(0,0,0,.55);color:white;border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;font-size:14px;pointer-events:none;z-index:2';
            wrapper.appendChild(hint);
        }

        vizitAvatar.onclick = () => {
            const input = document.createElement('input');
            input.type   = 'file';
            input.accept = 'image/*';
            input.onchange = async () => {
                const file = input.files[0];
                if (!file) return;
                const fd = new FormData();
                fd.append('photo', file);
                try {
                    const res  = await fetch('/api/upload/card-photo', { method: 'POST', credentials: 'include', body: fd });
                    const json = await res.json();
                    if (json.ok) { setCardPhoto(json.url); showSuccess('Фото загружено. Не забудьте сохранить.'); }
                    else showError(json.message || 'Ошибка загрузки');
                } catch { showError('Ошибка загрузки фото'); }
            };
            input.click();
        };
    }

    // ── Сохранить ─────────────────────────────────────────────────────────────
    async function handleSave() {
        const newData    = collectData();
        const mergedData = Object.assign({}, currentCard?.data || {}, newData);
        const title = isCompany
            ? (mergedData.campaignName || 'Корпоративная визитка')
            : (mergedData.fullName || mergedData.name || 'Личная визитка');

        const result = currentCard
            ? await cards.update(currentCard.id, { title, data: mergedData })
            : await cards.create({ type: cardType, title, data: mergedData });

        if (result.ok) {
            currentCard = result.card;
            history.replaceState(null, '', `?id=${currentCard.id}`);
            showSuccess('Сохранено!');
            const viewBtn = document.getElementById('viewCard');
            if (viewBtn) { viewBtn.style.display = ''; viewBtn.href = `card-view.html?id=${currentCard.id}`; }
        } else {
            showError(result.message || 'Ошибка сохранения');
        }
    }

    function handleReset() {
        if (currentCard) { fillForm(currentCard.data); showSuccess('Изменения сброшены'); }
        else FIELD_KEYS.forEach(key => document.querySelectorAll(`#${key}`).forEach(el => { el.value = ''; }));
    }

    // ── Навесить обработчики кнопок ───────────────────────────────────────────
    // Используем onclick вместо addEventListener — при bfcache-возврате
    // addEventListener может навесить обработчик повторно, onclick — нет.
    ['save', 'save2'].forEach(id => {
        const btn = document.getElementById(id);
        if (!btn) return;
        btn.onclick = async () => {
            btn.disabled    = true;
            btn.textContent = 'Сохранение...';
            await handleSave();
            btn.disabled  = false;
            btn.innerHTML = '<b>Сохранить изменения</b>';
        };
    });

    ['reset', 'reset2'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.onclick = handleReset;
    });

    // ── Кнопка просмотра ──────────────────────────────────────────────────────
    const viewBtn = document.getElementById('viewCard');
    if (viewBtn) {
        if (cardId) { viewBtn.style.display = ''; viewBtn.href = `card-view.html?id=${cardId}`; }
        else viewBtn.style.display = 'none';
    }

    // ── Загрузить данные визитки ──────────────────────────────────────────────
    // Делаем в конце чтобы кнопки уже были готовы
    if (cardId) {
        cards.get(cardId).then(result => {
            if (result.ok) {
                currentCard = result.card;
                fillForm(currentCard.data);
            } else {
                showError('Визитка не найдена. Будет создана новая.');
            }
        });
    }
}

// ── Точки входа ───────────────────────────────────────────────────────────────

// 1. Обычная загрузка: authState.js диспатчит событие после проверки сессии
window.addEventListener('viziq:authReady', () => {
    _initialized = false;  // сброс флага — страница загружена заново
    initSettings();
});

// 2. Возврат через кнопку "Назад" (bfcache): pageshow с persisted=true
//    В этом случае viziq:authReady уже не повторится, но VIZIQ уже заполнен
window.addEventListener('pageshow', (e) => {
    if (e.persisted) {
        _initialized = false;  // сброс флага — нужна повторная инициализация
        // VIZIQ.isGuest уже определён из прошлой загрузки, можно сразу
        if (window.VIZIQ && window.VIZIQ.isGuest !== undefined) {
            initSettings();
        }
    }
});
