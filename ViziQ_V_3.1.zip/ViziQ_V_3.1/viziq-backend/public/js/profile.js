/**
 * js/profile.js — страница профиля
 */

window.addEventListener('viziq:authReady', async ({ detail }) => {
    const { cards, isGuest, currentUser } = window.VIZIQ;

    if (isGuest) { showGuestBanner(); return; }

    await loadCards();
    initAvatarUpload();

    // ── Загрузка и рендер визиток ─────────────────────────────────────────────
    async function loadCards() {
        const container = document.getElementById('cards-container');
        if (!container) return;
        container.innerHTML = '<p class="text-muted p-3">Загрузка...</p>';

        const result = await cards.list();
        if (!result.ok) {
            container.innerHTML = `<p class="text-danger p-3">Ошибка: ${result.message}</p>`;
            return;
        }

        container.innerHTML = result.cards.length
            ? result.cards.map(buildCardHtml).join('') + buildAddCardHtml()
            : buildEmptyState();

        // Удаление визитки
        container.querySelectorAll('[data-delete-card]').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                if (!confirm('Удалить эту визитку?')) return;
                const r = await cards.remove(btn.dataset.deleteCard);
                if (r.ok) { showSuccess('Визитка удалена'); loadCards(); }
                else showError(r.message);
            });
        });

        // Клик по карточке — редактировать
        container.querySelectorAll('[data-card-id]').forEach(el => {
            el.addEventListener('click', () => {
                const page = el.dataset.cardType === 'company'
                    ? 'Setting-Page-Campaign.html'
                    : 'Setting-Page-Personal.html';
                window.location = `${page}?id=${el.dataset.cardId}`;
            });
        });
    }

    function buildCardHtml(card) {
        const date  = new Date(card.created_at).toLocaleDateString('ru-RU');
        const label = card.type === 'company' ? '🏢 Компания' : '👤 Личная';
        const photo = card.data?.cardPhoto || '';
        const bg    = photo
            ? `background:url('${photo}') center/cover`
            : 'background:linear-gradient(135deg,#7900E9,#374BD1)';
        return `
            <div class="col-12 col-sm-6 col-lg-4">
                <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden card-vcard position-relative"
                     data-card-id="${card.id}" data-card-type="${card.type}" style="cursor:pointer;">
                    <button data-delete-card="${card.id}"
                        class="btn btn-sm btn-danger position-absolute top-0 end-0 m-2 rounded-circle"
                        style="width:28px;height:28px;padding:0;font-size:13px;z-index:5;" title="Удалить">✕</button>
                    <div style="height:130px;${bg};"></div>
                    <div class="p-3">
                        <h5 class="fw-bold mb-1">${escHtml(card.title)}</h5>
                        <p class="small text-muted mb-0">${label} · ${date}</p>
                    </div>
                </div>
            </div>`;
    }

    function buildAddCardHtml() {
        return `
            <div class="col-12 col-sm-6 col-lg-4">
                <a href="choice.html" class="text-decoration-none h-100">
                    <div class="add-vcard-zone d-flex flex-column justify-content-center align-items-center rounded-4 h-100" style="min-height:200px;">
                        <div class="plus-circle mb-3"><span class="plus-icon">+</span></div>
                        <span class="fw-bold text-primary">Создать новую</span>
                    </div>
                </a>
            </div>`;
    }

    function buildEmptyState() {
        return `
            <div class="col-12 text-center py-5">
                <p class="text-muted mb-3">У вас ещё нет визиток.</p>
                <a href="choice.html" class="btn btn-primary rounded-pill px-4">Создать первую</a>
            </div>`;
    }

    // ── Загрузка аватара профиля ──────────────────────────────────────────────
    function initAvatarUpload() {
        // Находим аватар в шапке профиля (маленький, 45px)
        const headerAvatar = document.querySelector('img.rounded-circle[style*="45px"]')
                          || document.querySelector('img.rounded-circle');
        if (!headerAvatar) return;

        // Делаем его кликабельным
        headerAvatar.style.cursor = 'pointer';
        headerAvatar.title = 'Нажмите чтобы сменить фото';

        headerAvatar.addEventListener('click', () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.onchange = async () => {
                const file = input.files[0];
                if (!file) return;
                const fd = new FormData();
                fd.append('photo', file);
                try {
                    const res = await fetch('/api/upload/avatar', {
                        method: 'POST',
                        credentials: 'include',
                        body: fd
                    });
                    const data = await res.json();
                    if (data.ok) {
                        // Обновить все аватары на странице
                        document.querySelectorAll('img.rounded-circle, #avatar').forEach(img => {
                            img.src = data.url + '?t=' + Date.now();
                        });
                        // Обновить кэш
                        const u = window.VIZIQ.session.load();
                        if (u) { u.avatar = data.url; window.VIZIQ.session.save(u); }
                        showSuccess('Фото профиля обновлено');
                    } else {
                        showError(data.message);
                    }
                } catch { showError('Ошибка загрузки фото'); }
            };
            input.click();
        });
    }

    function showGuestBanner() {
        const main = document.querySelector('.container');
        if (main) main.innerHTML = `
            <div class="text-center py-5">
                <h3>Войдите в аккаунт</h3>
                <p class="text-muted">Чтобы просматривать профиль, необходима авторизация.</p>
                <a href="registration_window.html" class="btn btn-primary rounded-pill px-4">Войти / Зарегистрироваться</a>
            </div>`;
    }

    function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
});
