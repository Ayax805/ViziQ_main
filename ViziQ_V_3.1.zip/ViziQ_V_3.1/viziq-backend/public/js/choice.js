/**
 * js/choice.js — логика страницы выбора типа визитки (choice.html)
 *
 * Подключить:
 *   <script src="js/api.js"></script>
 *   <script src="js/authState.js"></script>
 *   <script src="js/choice.js"></script>
 */

window.addEventListener('viziq:authReady', ({ detail }) => {
    const { isGuest } = window.VIZIQ;

    const soloBtn     = document.getElementById('soloBtn');
    const campaignBtn = document.getElementById('compaignBtn');

    function goOrLogin(destination) {
        if (isGuest) {
            if (confirm('Для создания визитки необходимо войти в аккаунт. Перейти к регистрации?')) {
                window.location = 'registration_window.html';
            }
            return;
        }
        window.location = destination;
    }

    if (soloBtn) {
        soloBtn.addEventListener('click', () => goOrLogin('Setting-Page-Personal.html'));
    }
    if (campaignBtn) {
        campaignBtn.addEventListener('click', () => goOrLogin('Setting-Page-Campaign.html'));
    }
});
