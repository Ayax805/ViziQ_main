/**
 * middleware/auth.js
 * Проверяет JWT из куки или заголовка Authorization.
 * При ошибке возвращает JSON с кодом ошибки.
 */

const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../config');

function authMiddleware(req, res, next) {
    // Берём токен из куки или из заголовка Bearer
    const token =
        req.cookies?.viziq_token ||
        (req.headers.authorization || '').replace('Bearer ', '');

    if (!token) {
        return res.status(401).json({
            ok:      false,
            code:    'AUTH_REQUIRED',
            message: 'Требуется авторизация'
        });
    }

    try {
        const payload = jwt.verify(token, JWT_SECRET);
        req.user = payload;   // { id, email, username }
        next();
    } catch (err) {
        const code =
            err.name === 'TokenExpiredError' ? 'TOKEN_EXPIRED' : 'TOKEN_INVALID';
        return res.status(401).json({
            ok:      false,
            code,
            message: 'Токен недействителен или истёк'
        });
    }
}

module.exports = { authMiddleware };
