/**
 * middleware/adminAuth.js
 * Проверяет что пользователь является администратором.
 * Должен использоваться ПОСЛЕ authMiddleware.
 */

const { get } = require('../db');

function adminMiddleware(req, res, next) {
    const user = get('SELECT role FROM users WHERE id = ?', [req.user.id]);
    
    if (!user || user.role !== 'admin') {
        return res.status(403).json({
            ok:      false,
            code:    'ADMIN_REQUIRED',
            message: 'Доступ запрещён. Требуются права администратора.'
        });
    }
    
    next();
}

module.exports = { adminMiddleware };
