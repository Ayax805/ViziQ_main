/**
 * routes/auth.js
 * POST /api/auth/register  — регистрация
 * POST /api/auth/login     — вход
 * POST /api/auth/logout    — выход (очистка куки)
 * GET  /api/auth/me        — получить текущего пользователя
 */

const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const router   = express.Router();

const { get, run }   = require('../db');
const { authMiddleware } = require('../middleware/auth');
const { JWT_SECRET, JWT_EXPIRES_IN } = require('../config');

// ── Вспомогательная функция: создать и установить куки с токеном ──────────────
function setTokenCookie(res, token) {
    res.cookie('viziq_token', token, {
        httpOnly: true,          // недоступен из JS (защита от XSS)
        sameSite: 'lax',
        maxAge:   24 * 60 * 60 * 1000   // 24 часа в мс
    });
}

// ── POST /api/auth/register ───────────────────────────────────────────────────
router.post('/register', async (req, res, next) => {
    try {
        const { email, password, username } = req.body;

        // Валидация
        if (!email || !password || !username) {
            return res.status(400).json({
                ok:      false,
                code:    'VALIDATION_ERROR',
                message: 'Поля email, password и username обязательны'
            });
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return res.status(400).json({
                ok:      false,
                code:    'INVALID_EMAIL',
                message: 'Некорректный формат email'
            });
        }
        if (password.length < 6) {
            return res.status(400).json({
                ok:      false,
                code:    'WEAK_PASSWORD',
                message: 'Пароль должен содержать минимум 6 символов'
            });
        }

        // Проверка уникальности email
        const existing = get('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
        if (existing) {
            return res.status(409).json({
                ok:      false,
                code:    'EMAIL_TAKEN',
                message: 'Пользователь с таким email уже существует'
            });
        }

        // Хэшируем пароль
        const hash = await bcrypt.hash(password, 12);

        // Сохраняем
        run(
            'INSERT INTO users (email, password, username) VALUES (?, ?, ?)',
            [email.toLowerCase(), hash, username.trim()]
        );

        const user = get('SELECT id, email, username FROM users WHERE email = ?', [email.toLowerCase()]);

        // Выдаём токен
        const token = jwt.sign(
            { id: user.id, email: user.email, username: user.username },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRES_IN }
        );
        setTokenCookie(res, token);

        return res.status(201).json({
            ok:    true,
            code:  'REGISTERED',
            token,
            user:  { id: user.id, email: user.email, username: user.username }
        });

    } catch (err) {
        next(err);
    }
});

// ── POST /api/auth/login ──────────────────────────────────────────────────────
router.post('/login', async (req, res, next) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                ok:      false,
                code:    'VALIDATION_ERROR',
                message: 'Поля email и password обязательны'
            });
        }

        const user = get('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
        if (!user) {
            return res.status(401).json({
                ok:      false,
                code:    'WRONG_CREDENTIALS',
                message: 'Неверный email или пароль'
            });
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({
                ok:      false,
                code:    'WRONG_CREDENTIALS',
                message: 'Неверный email или пароль'
            });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email, username: user.username },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRES_IN }
        );
        setTokenCookie(res, token);

        return res.json({
            ok:    true,
            code:  'LOGGED_IN',
            token,
            user:  { id: user.id, email: user.email, username: user.username, role: user.role }
        });

    } catch (err) {
        next(err);
    }
});

// ── POST /api/auth/register-admin ─────────────────────────────────────────────
// Регистрация администратора (только со страницы админской регистрации)
router.post('/register-admin', async (req, res, next) => {
    try {
        const { email, password, username } = req.body;

        if (!email || !password || !username) {
            return res.status(400).json({
                ok:      false,
                code:    'VALIDATION_ERROR',
                message: 'Поля email, password и username обязательны'
            });
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return res.status(400).json({
                ok:      false,
                code:    'INVALID_EMAIL',
                message: 'Некорректный формат email'
            });
        }
        if (password.length < 6) {
            return res.status(400).json({
                ok:      false,
                code:    'WEAK_PASSWORD',
                message: 'Пароль должен содержать минимум 6 символов'
            });
        }

        const existing = get('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
        if (existing) {
            return res.status(409).json({
                ok:      false,
                code:    'EMAIL_TAKEN',
                message: 'Пользователь с таким email уже существует'
            });
        }

        const hash = await bcrypt.hash(password, 12);

        run(
            "INSERT INTO users (email, password, username, role) VALUES (?, ?, ?, 'admin')",
            [email.toLowerCase(), hash, username.trim()]
        );

        const user = get('SELECT id, email, username, role FROM users WHERE email = ?', [email.toLowerCase()]);

        const token = jwt.sign(
            { id: user.id, email: user.email, username: user.username, role: 'admin' },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRES_IN }
        );
        setTokenCookie(res, token);

        return res.status(201).json({
            ok:    true,
            code:  'ADMIN_REGISTERED',
            token,
            user:  { id: user.id, email: user.email, username: user.username, role: 'admin' }
        });

    } catch (err) {
        next(err);
    }
});

// ── POST /api/auth/login-admin ────────────────────────────────────────────────
// Вход исключительно для администраторов
router.post('/login-admin', async (req, res, next) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                ok:      false,
                code:    'VALIDATION_ERROR',
                message: 'Поля email и password обязательны'
            });
        }

        const user = get('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
        if (!user) {
            return res.status(401).json({
                ok:      false,
                code:    'WRONG_CREDENTIALS',
                message: 'Неверный email или пароль'
            });
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({
                ok:      false,
                code:    'WRONG_CREDENTIALS',
                message: 'Неверный email или пароль'
            });
        }

        // Проверяем роль: доступ только у пользователей с role === 'admin'
        if (user.role !== 'admin') {
            return res.status(403).json({
                ok:      false,
                code:    'NOT_AN_ADMIN',
                message: 'У этого аккаунта нет прав администратора. Вход разрешён только для администраторов.'
            });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email, username: user.username, role: 'admin' },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRES_IN }
        );
        setTokenCookie(res, token);

        return res.json({
            ok:    true,
            code:  'ADMIN_LOGGED_IN',
            token,
            user:  { id: user.id, email: user.email, username: user.username, role: 'admin' }
        });

    } catch (err) {
        next(err);
    }
});

// ── POST /api/auth/logout ─────────────────────────────────────────────────────
router.post('/logout', (req, res) => {
    res.clearCookie('viziq_token');
    return res.json({ ok: true, code: 'LOGGED_OUT', message: 'Выход выполнен' });
});

// ── GET /api/auth/me ──────────────────────────────────────────────────────────
router.get('/me', authMiddleware, (req, res) => {
    const user = get(
        'SELECT id, email, username, avatar, role, created_at FROM users WHERE id = ?',
        [req.user.id]
    );
    if (!user) {
        return res.status(404).json({ ok: false, code: 'USER_NOT_FOUND', message: 'Пользователь не найден' });
    }
    return res.json({ ok: true, user });
});


module.exports = router;
