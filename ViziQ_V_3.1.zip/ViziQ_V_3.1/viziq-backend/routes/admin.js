/**
 * routes/admin.js — API администратора VIZIQ
 *
 * Все маршруты защищены authMiddleware + adminMiddleware.
 * Префикс: /api/admin
 */

const express = require('express');
const router  = express.Router();
const { query, get, run } = require('../db');

// ── GET /api/admin/stats ─────────────────────────────────────────────────────
// Статистика: кол-во пользователей, визиток, последняя активность
router.get('/stats', (req, res) => {
    const totalUsers  = get('SELECT COUNT(*) as count FROM users');
    const totalCards  = get('SELECT COUNT(*) as count FROM cards');
    const totalAdmins = get("SELECT COUNT(*) as count FROM users WHERE role = 'admin'");
    const personalCards = get("SELECT COUNT(*) as count FROM cards WHERE type = 'personal'");
    const companyCards  = get("SELECT COUNT(*) as count FROM cards WHERE type = 'company'");
    
    const recentUsers = query(
        'SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 5'
    );
    const recentCards = query(
        `SELECT c.id, c.title, c.type, c.created_at, u.username as owner 
         FROM cards c JOIN users u ON u.id = c.user_id 
         ORDER BY c.created_at DESC LIMIT 5`
    );
    
    res.json({
        ok: true,
        stats: {
            totalUsers:    totalUsers?.count || 0,
            totalCards:    totalCards?.count || 0,
            totalAdmins:   totalAdmins?.count || 0,
            personalCards: personalCards?.count || 0,
            companyCards:  companyCards?.count || 0
        },
        recentUsers,
        recentCards
    });
});

// ── GET /api/admin/users ─────────────────────────────────────────────────────
// Список всех пользователей
router.get('/users', (req, res) => {
    const search = req.query.search || '';
    let users;
    if (search) {
        users = query(
            `SELECT id, username, email, avatar, role, created_at FROM users 
             WHERE username LIKE ? OR email LIKE ? 
             ORDER BY created_at DESC`,
            [`%${search}%`, `%${search}%`]
        );
    } else {
        users = query('SELECT id, username, email, avatar, role, created_at FROM users ORDER BY created_at DESC');
    }
    
    // Добавить кол-во визиток для каждого пользователя
    const usersWithCards = users.map(u => {
        const cardCount = get('SELECT COUNT(*) as count FROM cards WHERE user_id = ?', [u.id]);
        return { ...u, cardCount: cardCount?.count || 0 };
    });
    
    res.json({ ok: true, users: usersWithCards });
});

// ── DELETE /api/admin/users/:id ──────────────────────────────────────────────
// Удалить пользователя и все его визитки
router.delete('/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    
    // Нельзя удалить самого себя
    if (userId === req.user.id) {
        return res.status(400).json({ ok: false, code: 'SELF_DELETE', message: 'Нельзя удалить свой аккаунт' });
    }
    
    const user = get('SELECT id, username FROM users WHERE id = ?', [userId]);
    if (!user) {
        return res.status(404).json({ ok: false, code: 'USER_NOT_FOUND', message: 'Пользователь не найден' });
    }
    
    // Удалить визитки пользователя
    run('DELETE FROM cards WHERE user_id = ?', [userId]);
    // Удалить сессии
    run('DELETE FROM sessions WHERE user_id = ?', [userId]);
    // Удалить пользователя
    run('DELETE FROM users WHERE id = ?', [userId]);
    
    res.json({ ok: true, code: 'USER_DELETED', message: `Пользователь "${user.username}" удалён` });
});

// ── PUT /api/admin/users/:id/role ────────────────────────────────────────────
// Изменить роль пользователя (user/admin)
router.put('/users/:id/role', (req, res) => {
    const userId = parseInt(req.params.id);
    const { role } = req.body;
    
    if (!['user', 'admin'].includes(role)) {
        return res.status(400).json({ ok: false, code: 'INVALID_ROLE', message: 'Роль должна быть "user" или "admin"' });
    }
    
    // Нельзя снять роль с себя
    if (userId === req.user.id && role !== 'admin') {
        return res.status(400).json({ ok: false, code: 'SELF_DEMOTE', message: 'Нельзя снять с себя права администратора' });
    }
    
    const user = get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!user) {
        return res.status(404).json({ ok: false, code: 'USER_NOT_FOUND', message: 'Пользователь не найден' });
    }
    
    run('UPDATE users SET role = ? WHERE id = ?', [role, userId]);
    
    res.json({ ok: true, code: 'ROLE_UPDATED', message: `Роль обновлена на "${role}"` });
});

// ── GET /api/admin/cards ─────────────────────────────────────────────────────
// Список всех визиток всех пользователей
router.get('/cards', (req, res) => {
    const search = req.query.search || '';
    const type   = req.query.type || '';
    
    let sql = `SELECT c.id, c.type, c.title, c.data, c.created_at, c.updated_at,
                      u.username as owner, u.email as owner_email, c.user_id
               FROM cards c JOIN users u ON u.id = c.user_id`;
    const conditions = [];
    const params = [];
    
    if (search) {
        conditions.push('(c.title LIKE ? OR u.username LIKE ?)');
        params.push(`%${search}%`, `%${search}%`);
    }
    if (type && ['personal', 'company'].includes(type)) {
        conditions.push('c.type = ?');
        params.push(type);
    }
    
    if (conditions.length) {
        sql += ' WHERE ' + conditions.join(' AND ');
    }
    sql += ' ORDER BY c.created_at DESC';
    
    const cards = query(sql, params).map(c => {
        let data = {};
        try { data = JSON.parse(c.data); } catch {}
        return { ...c, data };
    });
    
    res.json({ ok: true, cards });
});

// ── DELETE /api/admin/cards/:id ──────────────────────────────────────────────
// Удалить любую визитку
router.delete('/cards/:id', (req, res) => {
    const card = get('SELECT id, title FROM cards WHERE id = ?', [req.params.id]);
    if (!card) {
        return res.status(404).json({ ok: false, code: 'CARD_NOT_FOUND', message: 'Визитка не найдена' });
    }
    
    run('DELETE FROM cards WHERE id = ?', [req.params.id]);
    res.json({ ok: true, code: 'CARD_DELETED', message: `Визитка "${card.title}" удалена` });
});

module.exports = router;
