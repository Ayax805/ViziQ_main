/**
 * config.js — настройки приложения
 *
 * ⚠️  В продакшене замените JWT_SECRET на длинную случайную строку
 *     и вынесите в переменные окружения (.env).
 */

module.exports = {
    // Секрет для подписи JWT.
    // Меняйте это значение перед деплоем!
    JWT_SECRET: process.env.JWT_SECRET || 'viziq_super_secret_change_me_2026',

    // Время жизни access-токена (24 часа = "запомнить на сутки")
    JWT_EXPIRES_IN: '24h',

    // Настройки SMTP для отправки писем (опционально)
    // Если SMTP не настроен — письма будут выводиться в консоль
    SMTP: {
        host:    process.env.SMTP_HOST    || '',
        port:    parseInt(process.env.SMTP_PORT) || 587,
        secure:  false,
        user:    process.env.SMTP_USER    || '',
        pass:    process.env.SMTP_PASS    || '',
        from:    process.env.SMTP_FROM    || 'noreply@viziq.ru'
    }
};
