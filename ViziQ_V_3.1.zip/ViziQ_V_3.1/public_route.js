/**
 * routes/public.js — публичный доступ к визиткам (без авторизации)
 *
 * GET /api/public/card/:id  — данные визитки для публичного просмотра
 * GET /api/public/user/:id  — публичные данные пользователя (аватар, имя)
 */

const express = require('express');
const router  = express.Router();
const { get } = require('../db');

// ── GET /api/public/card/:id ──────────────────────────────────────────────────
router.get('/card/:id', (req, res) => {
    const card = get(
        `SELECT c.id, c.type, c.title, c.data, c.created_at,
                u.username, u.avatar as user_avatar
         FROM cards c
         JOIN users u ON u.id = c.user_id
         WHERE c.id = ?`,
        [req.params.id]
    );

    if (!card) {
        return res.status(404).json({ ok: false, code: 'CARD_NOT_FOUND', message: 'Визитка не найдена' });
    }

    let data = {};
    try { data = JSON.parse(card.data); } catch {}

    res.json({
        ok:   true,
        card: {
            id:           card.id,
            type:         card.type,
            title:        card.title,
            created_at:   card.created_at,
            owner:        card.username,
            user_avatar:  card.user_avatar,
            data
        }
    });
});

module.exports = router;
